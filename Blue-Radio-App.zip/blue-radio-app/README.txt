BLUE RADIO

This is a minimal installable web app package. It opens to a completely blank white screen and uses the supplied Blue Radio icon.

IMPORTANT: This package is a PWA, not a signed Android APK. To install it on Android:
1. Upload the contents of this folder to a static web host that serves HTTPS (for example, a static site host).
2. Open the hosted address in Chrome on your Android phone.
3. Open Chrome's menu and choose "Install app" or "Add to Home screen".

No radio playback, buttons, tracking, analytics, or background tasks are included.
